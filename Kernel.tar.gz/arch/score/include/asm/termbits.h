#ifndef _ASM_SCORE_TERMBITS_H
#define _ASM_SCORE_TERMBITS_H

#include <asm-generic/termbits.h>

#endif /* _ASM_SCORE_TERMBITS_H */
