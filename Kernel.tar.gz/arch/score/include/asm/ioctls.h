#ifndef _ASM_SCORE_IOCTLS_H
#define _ASM_SCORE_IOCTLS_H

#include <asm-generic/ioctls.h>

#endif /* _ASM_SCORE_IOCTLS_H */
