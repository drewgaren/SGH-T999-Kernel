#ifndef _ASM_SCORE_IO_H
#define _ASM_SCORE_IO_H

#include <asm-generic/io.h>

#define virt_to_bus	virt_to_phys
#define bus_to_virt	phys_to_virt

#endif /* _ASM_SCORE_IO_H */
