#ifndef _ASM_SCORE_HW_IRQ_H
#define _ASM_SCORE_HW_IRQ_H

#endif /* _ASM_SCORE_HW_IRQ_H */
