#ifndef _ASM_SCORE_MUTEX_H
#define _ASM_SCORE_MUTEX_H

#include <asm-generic/mutex-dec.h>

#endif /* _ASM_SCORE_MUTEX_H */
