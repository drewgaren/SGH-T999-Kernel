#ifndef _ASM_SCORE_HARDIRQ_H
#define _ASM_SCORE_HARDIRQ_H

#include <asm-generic/hardirq.h>

#endif /* _ASM_SCORE_HARDIRQ_H */
