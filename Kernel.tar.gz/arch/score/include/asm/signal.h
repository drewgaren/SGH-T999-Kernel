#ifndef _ASM_SCORE_SIGNAL_H
#define _ASM_SCORE_SIGNAL_H

#include <asm-generic/signal.h>

#endif /* _ASM_SCORE_SIGNAL_H */
