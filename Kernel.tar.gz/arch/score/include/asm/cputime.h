#ifndef _ASM_SCORE_CPUTIME_H
#define _ASM_SCORE_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* _ASM_SCORE_CPUTIME_H */
