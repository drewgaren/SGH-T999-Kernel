#ifndef _ASM_SCORE_DMA_MAPPING_H
#define _ASM_SCORE_DMA_MAPPING_H

#include <asm-generic/dma-mapping-broken.h>

#endif /* _ASM_SCORE_DMA_MAPPING_H */
