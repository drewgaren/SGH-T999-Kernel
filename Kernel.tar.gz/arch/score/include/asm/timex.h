#ifndef _ASM_SCORE_TIMEX_H
#define _ASM_SCORE_TIMEX_H

#define CLOCK_TICK_RATE 27000000 /* Timer input freq. */

#include <asm-generic/timex.h>

#endif /* _ASM_SCORE_TIMEX_H */
