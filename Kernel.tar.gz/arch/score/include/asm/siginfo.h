#ifndef _ASM_SCORE_SIGINFO_H
#define _ASM_SCORE_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif /* _ASM_SCORE_SIGINFO_H */
