#ifndef _ASM_SCORE_SEMBUF_H
#define _ASM_SCORE_SEMBUF_H

#include <asm-generic/sembuf.h>

#endif /* _ASM_SCORE_SEMBUF_H */
