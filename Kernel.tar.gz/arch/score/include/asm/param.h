#ifndef _ASM_SCORE_PARAM_H
#define _ASM_SCORE_PARAM_H

#include <asm-generic/param.h>

#endif /* _ASM_SCORE_PARAM_H */
