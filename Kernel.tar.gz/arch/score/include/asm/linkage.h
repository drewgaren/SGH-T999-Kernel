#ifndef _ASM_SCORE_LINKAGE_H
#define _ASM_SCORE_LINKAGE_H

#define __ALIGN .align 2
#define __ALIGN_STR ".align 2"

#endif /* _ASM_SCORE_LINKAGE_H */
