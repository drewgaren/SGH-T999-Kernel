#ifndef _ASM_SCORE_SECTIONS_H
#define _ASM_SCORE_SECTIONS_H

#include <asm-generic/sections.h>

#endif /* _ASM_SCORE_SECTIONS_H */
