#ifndef _ASM_SCORE_ERRNO_H
#define _ASM_SCORE_ERRNO_H

#include <asm-generic/errno.h>

#endif /* _ASM_SCORE_ERRNO_H */
