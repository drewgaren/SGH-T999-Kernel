#ifndef _ASM_SCORE_MMU_H
#define _ASM_SCORE_MMU_H

typedef unsigned long mm_context_t;

#endif /* _ASM_SCORE_MMU_H */
