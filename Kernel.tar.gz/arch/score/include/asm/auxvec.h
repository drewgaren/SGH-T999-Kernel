#ifndef _ASM_SCORE_AUXVEC_H
#define _ASM_SCORE_AUXVEC_H

#endif /* _ASM_SCORE_AUXVEC_H */
