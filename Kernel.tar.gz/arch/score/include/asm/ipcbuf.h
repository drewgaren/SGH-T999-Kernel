#ifndef _ASM_SCORE_IPCBUF_H
#define _ASM_SCORE_IPCBUF_H

#include <asm-generic/ipcbuf.h>

#endif /* _ASM_SCORE_IPCBUF_H */
