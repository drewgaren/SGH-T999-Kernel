#ifndef _ASM_M68K_TOPOLOGY_H
#define _ASM_M68K_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* _ASM_M68K_TOPOLOGY_H */
