#ifndef _ASM_FUTEX_H
#define _ASM_FUTEX_H

#include <asm-generic/futex.h>

#endif
