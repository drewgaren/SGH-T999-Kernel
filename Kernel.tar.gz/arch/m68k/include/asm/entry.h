#ifdef __uClinux__
#include "entry_no.h"
#else
#include "entry_mm.h"
#endif
