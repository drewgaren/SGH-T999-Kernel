#ifndef _M68K_SCATTERLIST_H
#define _M68K_SCATTERLIST_H

#include <asm-generic/scatterlist.h>

#endif /* !(_M68K_SCATTERLIST_H) */
