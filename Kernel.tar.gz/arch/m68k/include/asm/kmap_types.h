#ifndef __ASM_M68K_KMAP_TYPES_H
#define __ASM_M68K_KMAP_TYPES_H

#include <asm-generic/kmap_types.h>

#endif	/* __ASM_M68K_KMAP_TYPES_H */
