#ifdef __uClinux__
#include "bitops_no.h"
#else
#include "bitops_mm.h"
#endif
