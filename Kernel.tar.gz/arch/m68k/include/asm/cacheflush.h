#ifdef __uClinux__
#include "cacheflush_no.h"
#else
#include "cacheflush_mm.h"
#endif
