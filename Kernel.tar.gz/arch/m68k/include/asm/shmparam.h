#ifndef _M68K_SHMPARAM_H
#define _M68K_SHMPARAM_H

#define	SHMLBA PAGE_SIZE		 /* attach addr a multiple of this */

#endif /* _M68K_SHMPARAM_H */
