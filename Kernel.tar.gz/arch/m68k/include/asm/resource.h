#ifndef _M68K_RESOURCE_H
#define _M68K_RESOURCE_H

#include <asm-generic/resource.h>

#endif /* _M68K_RESOURCE_H */
