#ifdef __uClinux__
#include "uaccess_no.h"
#else
#include "uaccess_mm.h"
#endif
