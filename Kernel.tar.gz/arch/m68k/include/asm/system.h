#ifdef __uClinux__
#include "system_no.h"
#else
#include "system_mm.h"
#endif
