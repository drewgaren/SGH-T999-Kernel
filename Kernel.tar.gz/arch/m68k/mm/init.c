#ifdef CONFIG_MMU
#include "init_mm.c"
#else
#include "init_no.c"
#endif
